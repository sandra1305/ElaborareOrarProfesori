﻿using DocumentFormat.OpenXml.Bibliography;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ElaborareOrarProfesori
{
    public partial class AdaugaDisciplina : Form
    {
        private string connectionString = "Data Source=dataBase.db";
        private  List<Discipline> discipline;
        public AdaugaDisciplina()
        {
            InitializeComponent();
            discipline = new List<Discipline>();
        }


        private void AddDisciplina(Discipline disciplina)
        {
            var query = "INSERT INTO Disciplina(Denumire,Facultate,An,Grupa,StudentiGrupa) VALUES(@denumire,  @facultate, @an,  @grupa,  @studentiGrupa); SELECT last_insert_rowid()";

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                SQLiteCommand command = new SQLiteCommand(query, connection);
                //command.Parameters.AddWithValue("@idProfesor",profesor.IdAngajat);
                command.Parameters.AddWithValue ("@denumire", disciplina.Denumire);
                command.Parameters.AddWithValue("@facultate", disciplina.Facultate);
                command.Parameters.AddWithValue("@an", disciplina.An);
                command.Parameters.AddWithValue("@grupa", disciplina.Grupa);
                command.Parameters.AddWithValue("@studentiGrupa", disciplina.StudentiGrupa);
                connection.Open();
                command.ExecuteScalar();
                disciplina.CodDisciplina = (int)command.ExecuteScalar();
                discipline.Add(disciplina);
            }
        }

        public void LoadDisciplina()
        {
            var query = "SELECT* FROM Disciplina";
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                SQLiteCommand command = new SQLiteCommand(query, connection);
                connection.Open();

                using (SQLiteDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int codDisciplina = (int)reader["CodDisciplina"];
                        string denumire = (string)reader["Denumire"];
                        string facultate = (string)reader["Facultate"];
                        int an = (int)reader["An"];
                        string grupa = (string)reader["Grupa"];
                        int studentiGrupa = (int)reader["StudentiGrupa"];
                        Discipline disciplina = new Discipline(denumire, facultate, an,grupa, studentiGrupa);
                        discipline.Add(disciplina);
                    }

                }


            }
        }
        private void tbNumarGrupa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)) e.Handled = true;        
            if (e.KeyChar == (char)8) e.Handled = false;            
            if (e.KeyChar == (char)13) btnSaveDisciplina_Click(sender, e);  

        }

        

        private void tbCodDisciplina_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)) 
                e.Handled = true;        
            if (e.KeyChar == (char)8) 
                e.Handled = false;
            if (e.KeyChar == (char)13) 
                btnSaveDisciplina_Click(sender, e);
        }

        private void tbDenumire_Validating(object sender, CancelEventArgs e)
        {
            if (tbDenumire.Text.Length < 2)
            {
                errorProvider1.SetError(tbDenumire, "Prenumele este prea scurt");
                e.Cancel = true;

            }
            else

                errorProvider1.SetError(tbDenumire, null);
        }

        private void tbFacultate_Validating(object sender, CancelEventArgs e)
        {
            if (tbFacultate.Text.Length < 2)
            {
                errorProvider1.SetError(tbFacultate, "Prenumele este prea scurt");
                e.Cancel = true;

            }
            else

                errorProvider1.SetError(tbFacultate, null);
        }

        private void btnSaveDisciplina_Click(object sender, EventArgs e)
        {
            var result = ValidateChildren();
            if (!result)
            {
                MessageBox.Show("Formularul contine erori", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            int codDisciplina = int.Parse(tbCodDisciplina.Text);
            String denumire = tbDenumire.Text;
            String facultate = tbFacultate.Text;
            int an = int.Parse(tbAn.Text);
            String grupa = tbGrupa.Text;
            int studentiGrupa = int.Parse(tbGrupa.Text);
            Discipline disciplina = new Discipline(codDisciplina, denumire, facultate, an, grupa, studentiGrupa);
            discipline.Add(disciplina);
            DisplayDiscipline();
        }

        private void DisplayDiscipline()
        {
            dgvDiscipline.Rows.Clear();
            foreach(Discipline disciplina in discipline)
            {
                int rowId = dgvDiscipline.Rows.Add(new object[]
                {
                    disciplina.CodDisciplina,
                    disciplina.Denumire,
                    disciplina.Facultate,
                    disciplina.An,
                    disciplina.Grupa,
                    disciplina.StudentiGrupa
                }) ;

                dgvDiscipline.Rows[rowId].Tag = disciplina;
               
            }
        }
      

        private void button2_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Discipline>));
            using (FileStream stream = File.Create("SerializedDiscipline.xml"))
            {

                serializer.Serialize(stream, discipline);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Discipline>));
            using (FileStream stream = File.OpenRead("SerializedDiscipline.xml"))
            {
                discipline = (List<Discipline>)serializer.Deserialize(stream);
                DisplayDiscipline();
            }
        }

        private void modificareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditDisciplina();
        }

        private void btnStergereDisciplina_Click(object sender, EventArgs e)
        {
            if (dgvDiscipline.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecteaza o disciplina");
                return;
            }
            if (MessageBox.Show("Esti sigur?", "Sterge disciplina", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {

                DataGridViewRow row = dgvDiscipline.SelectedRows[0];
                Discipline disciplina = (Discipline)row.Tag;
                discipline.Remove(disciplina);
                DisplayDiscipline();
            }
        }

        

        private void EditDisciplina()
        {
            if (dgvDiscipline.SelectedRows.Count == 0)
            {
                MessageBox.Show("Alege o disciplina");
                return;
            }

            DataGridViewRow row = dgvDiscipline.SelectedRows[0];
            Discipline disciplina = (Discipline)row.Tag;
            EditFormDisciplina editFormDisciplina = new EditFormDisciplina(disciplina);
            if (editFormDisciplina.ShowDialog() == DialogResult.OK)
                DisplayDiscipline();
        }

        private void dgvDiscipline_Click(object sender, EventArgs e)
        {

        }

        private void dgvDiscipline_DoubleClick(object sender, EventArgs e)
        {
            EditDisciplina();
        }

        private void AdaugaDisciplina_Load(object sender, EventArgs e)
        {
            //LoadDisciplina();
            DisplayDiscipline();
        }
    }
    }

