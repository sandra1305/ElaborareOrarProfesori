﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElaborareOrarProfesori
{
    public partial class editAdaugareClasa : Form
    {
        private Sali sala;
        public editAdaugareClasa()
        {
            InitializeComponent();
            this.sala = sala;
        }

        private void editAdaugareClasa_Load(object sender, EventArgs e)
        {
 
            tbNumeSala.DataBindings.Add("Text", this, "numeSala");
            tbCapacitate.DataBindings.Add("Text", this, "capacitateSala");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sala.NumeSala = tbNumeSala.Text;
            sala.Capacitate = int.Parse(tbCapacitate.Text);
        }
    }
}
