﻿namespace ElaborareOrarProfesori
{
    partial class MeniuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAdaugaProfesor = new System.Windows.Forms.Button();
            this.btnAdaugaDisciplina = new System.Windows.Forms.Button();
            this.btnAdaugaSala = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(this.btnAdaugaSala);
            this.groupBox1.Controls.Add(this.btnAdaugaDisciplina);
            this.groupBox1.Controls.Add(this.btnAdaugaProfesor);
            this.groupBox1.Location = new System.Drawing.Point(35, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(669, 387);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Pagina Principala";
            // 
            // btnAdaugaProfesor
            // 
            this.btnAdaugaProfesor.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAdaugaProfesor.Location = new System.Drawing.Point(236, 69);
            this.btnAdaugaProfesor.Name = "btnAdaugaProfesor";
            this.btnAdaugaProfesor.Size = new System.Drawing.Size(206, 48);
            this.btnAdaugaProfesor.TabIndex = 0;
            this.btnAdaugaProfesor.Text = "Adauga Profesor";
            this.btnAdaugaProfesor.UseVisualStyleBackColor = true;
            this.btnAdaugaProfesor.Click += new System.EventHandler(this.btnAdaugaProfesor_Click);
            // 
            // btnAdaugaDisciplina
            // 
            this.btnAdaugaDisciplina.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAdaugaDisciplina.Location = new System.Drawing.Point(236, 143);
            this.btnAdaugaDisciplina.Name = "btnAdaugaDisciplina";
            this.btnAdaugaDisciplina.Size = new System.Drawing.Size(206, 48);
            this.btnAdaugaDisciplina.TabIndex = 1;
            this.btnAdaugaDisciplina.Text = "Adauga Disciplina";
            this.btnAdaugaDisciplina.UseVisualStyleBackColor = true;
            this.btnAdaugaDisciplina.Click += new System.EventHandler(this.btnAdaugaDisciplina_Click);
            // 
            // btnAdaugaSala
            // 
            this.btnAdaugaSala.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAdaugaSala.Location = new System.Drawing.Point(236, 222);
            this.btnAdaugaSala.Name = "btnAdaugaSala";
            this.btnAdaugaSala.Size = new System.Drawing.Size(206, 48);
            this.btnAdaugaSala.TabIndex = 2;
            this.btnAdaugaSala.Text = "Adauga Sala";
            this.btnAdaugaSala.UseVisualStyleBackColor = true;
            this.btnAdaugaSala.Click += new System.EventHandler(this.btnAdaugaSala_Click);
            // 
            // MeniuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(749, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "MeniuPrincipal";
            this.Text = "Meniu Principal";
            this.Load += new System.EventHandler(this.MeniuPrincipalcs_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdaugaSala;
        private System.Windows.Forms.Button btnAdaugaDisciplina;
        private System.Windows.Forms.Button btnAdaugaProfesor;
    }
}