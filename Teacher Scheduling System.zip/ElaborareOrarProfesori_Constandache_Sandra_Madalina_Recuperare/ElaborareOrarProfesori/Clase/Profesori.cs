﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElaborareOrarProfesori
{
    [Serializable]
    public class Profesori
    {
        public int IdProfesor { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public DateTime DataNasterii { get; set; }
        public int TelMobil { get; set; }
        public Discipline Disciplina { get; set; }
        public Functie Functie { get; set; }

        public Profesori()
        {

        }
        public Profesori(int idProfesor,string nume, string prenume, int telMobil, DateTime dataNasterii, Discipline disciplina, Functie functie)
        {
            IdProfesor = idProfesor;
            Nume = nume;
            Prenume = prenume;
            DataNasterii = dataNasterii;
            TelMobil = telMobil;
            Disciplina = disciplina;
            Functie = functie;
        }
        


        
    }
}
