﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElaborareOrarProfesori
{
    [Serializable]
    public class Sali
    {
        public int IdSala { get; set; }
        public string NumeSala { get; set; }
        public int Capacitate { get; set; }
      
        public Sali()
        {

        }
    public Sali(int idSala, string numeSala, int capacitate )
    {
        IdSala = idSala;
        NumeSala = numeSala;
        Capacitate = capacitate;

    }

    public override String ToString()
    {
            return string.Format("IdSala(0), NumeSala(1), Capacitate(2)", IdSala, NumeSala, Capacitate);

    }
}
}

