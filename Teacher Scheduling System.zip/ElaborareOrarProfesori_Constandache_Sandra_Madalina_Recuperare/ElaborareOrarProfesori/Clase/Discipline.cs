﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElaborareOrarProfesori
{
    [Serializable]
    public class Discipline
    {
        
        public int CodDisciplina { get; set; }
        
        public string Denumire { get; set; }

        public string Facultate { get; set; }
        public int An { get; set; }
        public string Grupa { get; set; }
        public int StudentiGrupa { get; set; }

        public Discipline()
        {

        }

        public Discipline( string denumire, string facultate, int an, string grupa, int studentiGrupa)
        {
       
            Denumire = denumire;
            Facultate = facultate;
            An = an;
            Grupa = grupa;
            StudentiGrupa = studentiGrupa;
        }
        public Discipline(int codDisciplina,string denumire, string facultate, int an, String grupa, int studentiGrupa):this(denumire,  facultate, an,  grupa,  studentiGrupa)

        {
            CodDisciplina = codDisciplina;
        }
        public static Discipline FromDataReader(IDataReader reader)
        {
            int codDisciplina = reader["CodDisciplina"] != DBNull.Value ? (int)reader["CodDisciplina"] : 0;
            string denumire = reader["Denumire"] != DBNull.Value ? (string)reader["Denumire"] : "N/A";
            string facultate = reader["Facultate"] != DBNull.Value ? (string)reader["Facultate"] : "N/A";
            int an = reader["An"] != DBNull.Value ? (int)reader["An"] : 0;
            string grupa = reader["Grupa"] != DBNull.Value ? (string)reader["Grupa"] : "N/A";
            int studentiGrupa = reader["StudentiGrupa"] != DBNull.Value ? (int)reader["StudentiGrupa"] : 0;

            return new Discipline(codDisciplina, denumire, facultate, an, grupa, studentiGrupa);
        }
    }
   
}
