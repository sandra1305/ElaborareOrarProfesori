﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElaborareOrarProfesori
{
    public partial class MeniuPrincipal : Form
    {
        public MeniuPrincipal()
        {
            InitializeComponent();
        }

        private void MeniuPrincipalcs_Load(object sender, EventArgs e)
        {

        }

        private void btnAdaugaProfesor_Click(object sender, EventArgs e)
        {
            AdaugareProfesor editForm = new AdaugareProfesor();
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                
                editForm.Show();
            }
        }

        private void btnAdaugaSala_Click(object sender, EventArgs e)
        {
            AdaugaSalaClasa editForm = new AdaugaSalaClasa();
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                // Dacă utilizatorul a apăsat butonul "OK", puteți face aici ce doriți cu formularul
                editForm.Show();
            }
        }

        private void btnAdaugaDisciplina_Click(object sender, EventArgs e)
        {
            AdaugaDisciplina editForm = new AdaugaDisciplina();
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                // Dacă utilizatorul a apăsat butonul "OK", puteți face aici ce doriți cu formularul
                editForm.Show();
            }
        }
    }
}
