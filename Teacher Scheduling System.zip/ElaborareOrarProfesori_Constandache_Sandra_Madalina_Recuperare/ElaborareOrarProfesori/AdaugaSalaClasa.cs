﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ElaborareOrarProfesori
{
    public partial class AdaugaSalaClasa : Form
    {
        private readonly BindingList<Sali> _sali;
        private List<Sali> sali= new List<Sali>();
        public int codSala { get; set; }
        public string numeSala { get; set; }
        public int capacitateSala { get; set; }
        public AdaugaSalaClasa()
        {
            InitializeComponent();
            _sali = new BindingList<Sali>();
            dgvSali.DataSource = _sali;
            tbCodSala.DataBindings.Add("Text", this, "codSala");
            tbNumeSala.DataBindings.Add("Text", this, "numeSala");
            tbCapacitate.DataBindings.Add("Text", this, "capacitateSala");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        #region Events

        private void btnSave_Click(object sender, EventArgs e)
        {
            //int codSala = int.Parse(tbCodSala.Text);
            //String numeSala = tbNumeSala.Text;
            //int capacitateSala = int.Parse(tbCapacitate.Text);

            var sala = new Sali(codSala, numeSala, capacitateSala);
            _sali.Add(sala);
        }
        #endregion

        private void btnSerializare_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BindingList<Sali>));
            using (FileStream stream = File.Create("SerializareSala.xml"))
            {

                serializer.Serialize(stream, _sali);
            }
        }

        private void btnDeserealizare_Click(object sender, EventArgs e)
        {

            XmlSerializer serializer = new XmlSerializer(typeof(BindingList<Sali>));
            using (FileStream stream = File.OpenRead("SerializareSala.xml"))
            {
                _sali.Clear(); // Curățați lista existentă de săli înainte de a deserializa
                BindingList<Sali> saliDeserializate = (BindingList<Sali>)serializer.Deserialize(stream);
                foreach (var sala in saliDeserializate)
                {
                    _sali.Add(sala); // Adăugați fiecare sală deserializată în lista de săli existentă
                }
            }
        }
    }
}
