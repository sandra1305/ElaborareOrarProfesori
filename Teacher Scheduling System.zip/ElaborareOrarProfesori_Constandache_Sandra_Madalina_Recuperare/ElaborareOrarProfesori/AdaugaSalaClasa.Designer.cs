﻿namespace ElaborareOrarProfesori
{
    partial class AdaugaSalaClasa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvSali = new System.Windows.Forms.DataGridView();
            this.idSalaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeSalaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacitateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saliBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDeserealizare = new System.Windows.Forms.Button();
            this.btnSerializare = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.tbCapacitate = new System.Windows.Forms.TextBox();
            this.tbNumeSala = new System.Windows.Forms.TextBox();
            this.tbCodSala = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSali)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saliBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvSali
            // 
            this.dgvSali.AllowUserToAddRows = false;
            this.dgvSali.AutoGenerateColumns = false;
            this.dgvSali.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSali.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idSalaDataGridViewTextBoxColumn,
            this.numeSalaDataGridViewTextBoxColumn,
            this.capacitateDataGridViewTextBoxColumn});
            this.dgvSali.DataSource = this.saliBindingSource;
            this.dgvSali.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSali.Location = new System.Drawing.Point(0, 28);
            this.dgvSali.Name = "dgvSali";
            this.dgvSali.RowHeadersWidth = 51;
            this.dgvSali.RowTemplate.Height = 24;
            this.dgvSali.Size = new System.Drawing.Size(615, 428);
            this.dgvSali.TabIndex = 0;
            // 
            // idSalaDataGridViewTextBoxColumn
            // 
            this.idSalaDataGridViewTextBoxColumn.DataPropertyName = "IdSala";
            this.idSalaDataGridViewTextBoxColumn.HeaderText = "IdSala";
            this.idSalaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idSalaDataGridViewTextBoxColumn.Name = "idSalaDataGridViewTextBoxColumn";
            this.idSalaDataGridViewTextBoxColumn.Width = 125;
            // 
            // numeSalaDataGridViewTextBoxColumn
            // 
            this.numeSalaDataGridViewTextBoxColumn.DataPropertyName = "NumeSala";
            this.numeSalaDataGridViewTextBoxColumn.HeaderText = "NumeSala";
            this.numeSalaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numeSalaDataGridViewTextBoxColumn.Name = "numeSalaDataGridViewTextBoxColumn";
            this.numeSalaDataGridViewTextBoxColumn.Width = 125;
            // 
            // capacitateDataGridViewTextBoxColumn
            // 
            this.capacitateDataGridViewTextBoxColumn.DataPropertyName = "Capacitate";
            this.capacitateDataGridViewTextBoxColumn.HeaderText = "Capacitate";
            this.capacitateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.capacitateDataGridViewTextBoxColumn.Name = "capacitateDataGridViewTextBoxColumn";
            this.capacitateDataGridViewTextBoxColumn.Width = 125;
            // 
            // saliBindingSource
            // 
            this.saliBindingSource.DataSource = typeof(ElaborareOrarProfesori.Sali);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDeserealizare);
            this.groupBox1.Controls.Add(this.btnSerializare);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.tbCapacitate);
            this.groupBox1.Controls.Add(this.tbNumeSala);
            this.groupBox1.Controls.Add(this.tbCodSala);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(0, 276);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(615, 178);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Adaugare Sala de Clasa";
            // 
            // btnDeserealizare
            // 
            this.btnDeserealizare.Location = new System.Drawing.Point(377, 122);
            this.btnDeserealizare.Name = "btnDeserealizare";
            this.btnDeserealizare.Size = new System.Drawing.Size(95, 30);
            this.btnDeserealizare.TabIndex = 9;
            this.btnDeserealizare.Text = "Deserializare";
            this.btnDeserealizare.UseVisualStyleBackColor = true;
            this.btnDeserealizare.Click += new System.EventHandler(this.btnDeserealizare_Click);
            // 
            // btnSerializare
            // 
            this.btnSerializare.Location = new System.Drawing.Point(377, 71);
            this.btnSerializare.Name = "btnSerializare";
            this.btnSerializare.Size = new System.Drawing.Size(95, 30);
            this.btnSerializare.TabIndex = 8;
            this.btnSerializare.Text = "Serializare";
            this.btnSerializare.UseVisualStyleBackColor = true;
            this.btnSerializare.Click += new System.EventHandler(this.btnSerializare_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Cod Sala";
           
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(377, 18);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 30);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Adauga";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tbCapacitate
            // 
            this.tbCapacitate.Location = new System.Drawing.Point(105, 109);
            this.tbCapacitate.Name = "tbCapacitate";
            this.tbCapacitate.Size = new System.Drawing.Size(100, 22);
            this.tbCapacitate.TabIndex = 5;
            // 
            // tbNumeSala
            // 
            this.tbNumeSala.Location = new System.Drawing.Point(105, 71);
            this.tbNumeSala.Name = "tbNumeSala";
            this.tbNumeSala.Size = new System.Drawing.Size(100, 22);
            this.tbNumeSala.TabIndex = 4;
            // 
            // tbCodSala
            // 
            this.tbCodSala.Location = new System.Drawing.Point(105, 34);
            this.tbCodSala.Name = "tbCodSala";
            this.tbCodSala.Size = new System.Drawing.Size(100, 22);
            this.tbCodSala.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Capacitate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nume";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(491, -100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cod Sala";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(615, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // AdaugaSalaClasa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 456);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgvSali);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AdaugaSalaClasa";
            this.Text = "Adauga Sala";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSali)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saliBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSali;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.BindingSource saliBindingSource;
        private System.Windows.Forms.TextBox tbCapacitate;
        private System.Windows.Forms.TextBox tbNumeSala;
        private System.Windows.Forms.TextBox tbCodSala;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSalaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeSalaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacitateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDeserealizare;
        private System.Windows.Forms.Button btnSerializare;
        private System.Windows.Forms.MenuStrip menuStrip1;
    }
}