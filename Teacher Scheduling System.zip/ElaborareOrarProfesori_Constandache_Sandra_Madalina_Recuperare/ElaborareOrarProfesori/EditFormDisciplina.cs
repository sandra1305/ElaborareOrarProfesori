﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ElaborareOrarProfesori
{
    public partial class EditFormDisciplina : Form
    {
        private Discipline disciplina;
        public EditFormDisciplina(Discipline disciplina)
        {
            InitializeComponent();
            this.disciplina = disciplina;
        }

        private void EditFormDisciplina_Load(object sender, EventArgs e)
        {
            tbDenumire.Text = disciplina.Denumire;
            tbFacultate.Text = disciplina.Facultate;
            tbAn.Text = disciplina.An.ToString();
            tbGrupa.Text = disciplina.Grupa;
            tbNumarStudenti.Text = disciplina.StudentiGrupa.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            disciplina.Denumire = tbDenumire.Text;
            disciplina.Facultate = tbFacultate.Text;
            disciplina.An = int.Parse(tbAn.Text);
            disciplina.Grupa = tbGrupa.Text;
            disciplina.StudentiGrupa = int.Parse(tbNumarStudenti.Text);
        }
    }
}
