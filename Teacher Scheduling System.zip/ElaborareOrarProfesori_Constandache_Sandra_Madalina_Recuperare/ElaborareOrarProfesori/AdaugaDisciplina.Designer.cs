﻿namespace ElaborareOrarProfesori
{
    partial class AdaugaDisciplina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvDiscipline = new System.Windows.Forms.DataGridView();
            this.CodDisciplina = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Disciplina = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Facultate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumarStudenti = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnEditDisciplina = new System.Windows.Forms.ToolStripMenuItem();
            this.btnStergereDisciplina = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbDenumire = new System.Windows.Forms.TextBox();
            this.tbCodDisciplina = new System.Windows.Forms.TextBox();
            this.tbFacultate = new System.Windows.Forms.TextBox();
            this.tbAn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbGrupa = new System.Windows.Forms.TextBox();
            this.tbNumarStudenti = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnSaveDisciplina = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiscipline)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDiscipline
            // 
            this.dgvDiscipline.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDiscipline.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CodDisciplina,
            this.Disciplina,
            this.Facultate,
            this.Column2,
            this.Column3,
            this.NumarStudenti});
            this.dgvDiscipline.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvDiscipline.Location = new System.Drawing.Point(302, 34);
            this.dgvDiscipline.Name = "dgvDiscipline";
            this.dgvDiscipline.RowHeadersWidth = 51;
            this.dgvDiscipline.RowTemplate.Height = 24;
            this.dgvDiscipline.Size = new System.Drawing.Size(486, 258);
            this.dgvDiscipline.TabIndex = 0;
            this.dgvDiscipline.Click += new System.EventHandler(this.dgvDiscipline_Click);
            this.dgvDiscipline.DoubleClick += new System.EventHandler(this.dgvDiscipline_DoubleClick);
            // 
            // CodDisciplina
            // 
            this.CodDisciplina.HeaderText = "Cod Disciplina";
            this.CodDisciplina.MinimumWidth = 6;
            this.CodDisciplina.Name = "CodDisciplina";
            this.CodDisciplina.Width = 125;
            // 
            // Disciplina
            // 
            this.Disciplina.HeaderText = "Disciplina";
            this.Disciplina.MinimumWidth = 6;
            this.Disciplina.Name = "Disciplina";
            this.Disciplina.Width = 125;
            // 
            // Facultate
            // 
            this.Facultate.HeaderText = "Facultate";
            this.Facultate.MinimumWidth = 6;
            this.Facultate.Name = "Facultate";
            this.Facultate.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "An";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Grupa";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 125;
            // 
            // NumarStudenti
            // 
            this.NumarStudenti.HeaderText = "Numar Studenti";
            this.NumarStudenti.MinimumWidth = 6;
            this.NumarStudenti.Name = "NumarStudenti";
            this.NumarStudenti.Width = 125;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnEditDisciplina,
            this.btnStergereDisciplina});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(151, 52);
            // 
            // btnEditDisciplina
            // 
            this.btnEditDisciplina.Name = "btnEditDisciplina";
            this.btnEditDisciplina.Size = new System.Drawing.Size(150, 24);
            this.btnEditDisciplina.Text = "Modificare";
            this.btnEditDisciplina.Click += new System.EventHandler(this.modificareToolStripMenuItem_Click);
            // 
            // btnStergereDisciplina
            // 
            this.btnStergereDisciplina.Name = "btnStergereDisciplina";
            this.btnStergereDisciplina.Size = new System.Drawing.Size(150, 24);
            this.btnStergereDisciplina.Text = "Stergere";
            this.btnStergereDisciplina.Click += new System.EventHandler(this.btnStergereDisciplina_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cod Disciplina";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Denumire";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Facultate";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "An";
            // 
            // tbDenumire
            // 
            this.tbDenumire.Location = new System.Drawing.Point(112, 85);
            this.tbDenumire.Name = "tbDenumire";
            this.tbDenumire.Size = new System.Drawing.Size(147, 22);
            this.tbDenumire.TabIndex = 5;
            this.tbDenumire.Validating += new System.ComponentModel.CancelEventHandler(this.tbDenumire_Validating);
            // 
            // tbCodDisciplina
            // 
            this.tbCodDisciplina.Location = new System.Drawing.Point(112, 53);
            this.tbCodDisciplina.Name = "tbCodDisciplina";
            this.tbCodDisciplina.Size = new System.Drawing.Size(147, 22);
            this.tbCodDisciplina.TabIndex = 5;
            this.tbCodDisciplina.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCodDisciplina_KeyPress);
            // 
            // tbFacultate
            // 
            this.tbFacultate.Location = new System.Drawing.Point(112, 122);
            this.tbFacultate.Name = "tbFacultate";
            this.tbFacultate.Size = new System.Drawing.Size(147, 22);
            this.tbFacultate.TabIndex = 6;
            this.tbFacultate.Validating += new System.ComponentModel.CancelEventHandler(this.tbFacultate_Validating);
            // 
            // tbAn
            // 
            this.tbAn.Location = new System.Drawing.Point(112, 157);
            this.tbAn.Name = "tbAn";
            this.tbAn.Size = new System.Drawing.Size(147, 22);
            this.tbAn.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Grupa";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Numar Studenti";
            // 
            // tbGrupa
            // 
            this.tbGrupa.Location = new System.Drawing.Point(112, 185);
            this.tbGrupa.Name = "tbGrupa";
            this.tbGrupa.Size = new System.Drawing.Size(147, 22);
            this.tbGrupa.TabIndex = 10;
            // 
            // tbNumarStudenti
            // 
            this.tbNumarStudenti.Location = new System.Drawing.Point(112, 217);
            this.tbNumarStudenti.Name = "tbNumarStudenti";
            this.tbNumarStudenti.Size = new System.Drawing.Size(147, 22);
            this.tbNumarStudenti.TabIndex = 11;
            this.tbNumarStudenti.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNumarGrupa_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.btnSaveDisciplina);
            this.groupBox1.Controls.Add(this.tbGrupa);
            this.groupBox1.Controls.Add(this.tbNumarStudenti);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbAn);
            this.groupBox1.Controls.Add(this.tbFacultate);
            this.groupBox1.Controls.Add(this.tbCodDisciplina);
            this.groupBox1.Controls.Add(this.tbDenumire);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(6, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(275, 429);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Adaugare Disciplina";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(73, 348);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 31);
            this.button3.TabIndex = 14;
            this.button3.Text = "Deserealizare XML";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(73, 314);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 28);
            this.button2.TabIndex = 13;
            this.button2.Text = "Serializare.XML";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnSaveDisciplina
            // 
            this.btnSaveDisciplina.Location = new System.Drawing.Point(73, 277);
            this.btnSaveDisciplina.Name = "btnSaveDisciplina";
            this.btnSaveDisciplina.Size = new System.Drawing.Size(111, 31);
            this.btnSaveDisciplina.TabIndex = 12;
            this.btnSaveDisciplina.Text = "Salveaza";
            this.btnSaveDisciplina.UseVisualStyleBackColor = true;
            this.btnSaveDisciplina.Click += new System.EventHandler(this.btnSaveDisciplina_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // AdaugaDisciplina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgvDiscipline);
            this.Name = "AdaugaDisciplina";
            this.Text = "AdaugaDisciplina";
            this.Load += new System.EventHandler(this.AdaugaDisciplina_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiscipline)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDiscipline;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbDenumire;
        private System.Windows.Forms.TextBox tbCodDisciplina;
        private System.Windows.Forms.TextBox tbFacultate;
        private System.Windows.Forms.TextBox tbAn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbGrupa;
        private System.Windows.Forms.TextBox tbNumarStudenti;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnSaveDisciplina;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CodDisciplina;
        private System.Windows.Forms.DataGridViewTextBoxColumn Disciplina;
        private System.Windows.Forms.DataGridViewTextBoxColumn Facultate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumarStudenti;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btnEditDisciplina;
        private System.Windows.Forms.ToolStripMenuItem btnStergereDisciplina;
    }
}