﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.Xml.Serialization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Text;
using DocumentFormat.OpenXml.Spreadsheet;
namespace ElaborareOrarProfesori
{



    public partial class AdaugareProfesor : Form
    {
        #region Attributes
        private string connectionString = "Data Source=dataBase.db";
        private  List<Profesori> profesori;
        #endregion

        public AdaugareProfesor()
        {
            InitializeComponent();

            profesori = new List<Profesori>();

            foreach (Functie functie in Enum.GetValues(typeof(Functie)))
            {
                comboFunctie.Items.Add(functie);
            }
        }


        #region Methods

        //private void AddProfesor(Profesori profesor)
        //{
        //    var query = "INSERT INTO Profesor(Nume,Prenume,DataNasterii,TelMobil,Disciplina,Functie) VALUES(@nume, @prenume, @dataNasterii,@telMobil, @functie,@disciplina); SELECT last_insert_rowid()";

        //    using (SQLiteConnection connection = new SQLiteConnection(connectionString)) 
        //    {
        //        SQLiteCommand command = new SQLiteCommand(query,connection);
        //        //command.Parameters.AddWithValue("@idProfesor",profesor.IdAngajat);
        //        command.Parameters.AddWithValue("@nume",profesor.Nume);
        //        command.Parameters.AddWithValue("@prenume",profesor.Prenume);
        //        command.Parameters.AddWithValue("@dataNasterii",profesor.DataNasterii);
        //        command.Parameters.AddWithValue("@telMobil", profesor.TelMobil);
        //        command.Parameters.AddWithValue("@functie", profesor.Functie);
        //        command.Parameters.AddWithValue("@disciplina", profesor.Disciplina);
        //        connection.Open();
        //        command.ExecuteScalar();
        //        profesor.IdProfesor = (int)command.ExecuteScalar();
        //        profesori.Add(profesor);
        //    }

        //}

        //public void LoadProfesori()
        //{
        //    var query = "SELECT* FROM Profesor";
        //    using (SQLiteConnection connection = new SQLiteConnection(connectionString))
        //    {
        //        SQLiteCommand command = new SQLiteCommand(query, connection);
        //        connection.Open();

        //        using (SQLiteDataReader reader = command.ExecuteReader())
        //        {
        //            while (reader.Read())
        //            {
        //                long idProfesor = (long)reader["IdProfesor"];
        //                string nume = (string)reader["Nume"];
        //                string prenume = (string)reader["Prenume"];
        //                DateTime dataNasterii = DateTime.Parse((string)reader["DataNasterii"]);
        //                int telMobil = int.Parse((string)reader["TelMobil"]);
        //                Functie functie = (Functie)Enum.Parse(typeof(Functie), (string)reader["Functie"]);

        //                Discipline disciplina = (Discipline)reader["Disciplina"];
        //                Profesori profesor = new Profesori(nume, prenume, telMobil, dataNasterii, disciplina, functie);
        //                profesori.Add(profesor);
        //            }

        //        }


        //    }
        //}
        private void tbNume_Validating(object sender, CancelEventArgs e)
        {

            if (tbNume.Text.Length < 2)
            {
                errorProvider.SetError(tbNume, "Numele este prea scurt");
                e.Cancel = true;
            }

            else
                errorProvider.SetError(tbNume, null);


        }

        private void tbPrenume_Validating(object sender, CancelEventArgs e)
        {

            if (tbPrenume.Text.Length < 2)
            {
                errorProvider.SetError(tbPrenume, "Prenumele este prea scurt");
                e.Cancel = true;

            }
            else

                errorProvider.SetError(tbPrenume, null);


        }



        private void tbMobil_Validating(object sender, CancelEventArgs e)
        {
            Regex phonenumber = new Regex("\\d{4}\\d{3}\\d{3}");
            if (phonenumber.IsMatch(tbMobil.Text) && tbMobil.Text.Length == 10)
            {
                errorProvider.SetError(tbMobil, null);


            }
            else
            {
                errorProvider.SetError(tbMobil, "Numar de telefon eronat");
                e.Cancel = true;

            }
        }

        private void tbCodProfesor_Validating(object sender, CancelEventArgs e)
        {

        }

        private void dtpDataNastere_Validating(object sender, CancelEventArgs e)
        {

            if (dtpDataNastere.Value > DateTime.Now)
            {
                errorProvider.SetError(dtpDataNastere, "Data Nasterii nu ar trebui sa fie in viitor");
                e.Cancel = true;
            }
            else
            {
                if (DateTime.Now.Year - dtpDataNastere.Value.Year < 18)
                {
                    errorProvider.SetError(dtpDataNastere, "Varsta este necorespunzatoare, angajatul trebuie sa aiba cel putin 18 ani");
                    e.Cancel = true;
                }
                else
                    errorProvider.SetError(dtpDataNastere, null);
            }
        }


        private void comboFunctie_SelectedIndexChanged(object sender, EventArgs e)
        {
            Functie functieSelectata = (Functie)comboFunctie.SelectedItem;
            MessageBox.Show("Ai selectat: " + functieSelectata.ToString());
        }
        #endregion
        #region Events
        private void btnAdaugareProfesor_Click_1(object sender, EventArgs e)
        {
            var result = ValidateChildren();
            if (!result)
            {
                MessageBox.Show("Formularul contine erori", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            int idProfesor = int.Parse(tbCodProfesor.Text);
            string nume = tbNume.Text;
            string prenume = tbPrenume.Text;
            DateTime dataNasterii = dtpDataNastere.Value;
            int telMobil = int.Parse(tbMobil.Text);
            Discipline disciplina =(Discipline)comboDisciplina.SelectedItem;
            Functie functie = (Functie)comboFunctie.SelectedItem;

            ListViewItem lvi = new ListViewItem(nume);
            lvi.SubItems.Add(idProfesor.ToString());
            lvi.SubItems.Add(prenume);
            lvi.SubItems.Add(dataNasterii.ToShortDateString());
            lvi.SubItems.Add(telMobil.ToString());
            lvProfesori.Items.Add(lvi);

            Profesori profesor = new Profesori(idProfesor, nume, prenume, telMobil, dataNasterii, disciplina, functie);
            profesori.Add(profesor);
            //AddProfesor(profesor);
            DisplayProfesori();
        }
        private void LoadDataAndPopulateComboBox()
        {
           
            XmlSerializer serializer = new XmlSerializer(typeof(List<Discipline>));
            using (StreamReader sr = new StreamReader("SerializedDiscipline.xml"))
            {
                List<Discipline> listaDiscipline = (List<Discipline>)serializer.Deserialize(sr);


                comboDisciplina.DataSource = listaDiscipline;
                comboDisciplina.DisplayMember = "Denumire";
                comboDisciplina.ValueMember = "CodDisciplina"; 
            }
        }

       
     
        private void DisplayProfesori()
        {
            lvProfesori.Items.Clear();
            foreach (Profesori profesor in profesori)
            {
                ListViewItem item = new ListViewItem(profesor.IdProfesor.ToString());
                item.SubItems.Add(profesor.Nume);
                item.SubItems.Add(profesor.Prenume);
                item.SubItems.Add(profesor.DataNasterii.ToShortDateString());
                item.SubItems.Add(profesor.TelMobil.ToString());
                item.SubItems.Add(profesor.Functie.ToString());
                item.SubItems.Add(profesor.Disciplina.Denumire.ToString());
                item.Tag = profesor;

                lvProfesori.Items.Add(item);
            }
        }

        

        private void btnSerializeBinary_Click(object sender, EventArgs e)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream stream = File.Create("serialized.bin"))
            {
                formatter.Serialize(stream, profesori);
            }

        }

        private void btnDeserializeBinary_Click(object sender, EventArgs e)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream stream = File.OpenRead("serialized.bin"))
            {
                profesori = (List<Profesori>)formatter.Deserialize(stream);

                DisplayProfesori();
            }
        }

        private void bntSerializeXML_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Profesori>));
            using (FileStream stream = File.Create("Serialized.xml"))
            {

                serializer.Serialize(stream, profesori);
            }
        }

        private void btnDeserializeXML_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Profesori>));
            using (FileStream stream = File.OpenRead("Serialized.xml"))
            {
                profesori = (List<Profesori>)serializer.Deserialize(stream);
                DisplayProfesori();
            }


        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV | *.csv";
            saveFileDialog.Title = "Save as CSV";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = File.CreateText(saveFileDialog.FileName))
                {
                    sw.WriteLine( "Nume\", \"Prenume\", \"Data Nasterii\", \"Mobil\", \"Functie\"");
                    foreach (Profesori profesor in profesori)
                    {
                        sw.Write( "\",\"" + profesor.Nume + "\",\"" + profesor.Prenume + "\",\"" + profesor.DataNasterii.ToShortDateString() + "\",\"" + profesor.TelMobil
                            + "\",\"" + profesor.Functie + "\"");
                    }
                }
            }

        }

        private void btnImport_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Path.GetPathRoot(Environment.SystemDirectory);
            openFileDialog.Filter = "CSV|*.csv";

            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string sFileName = openFileDialog.FileName;
                    foreach (var line in File.ReadLines(sFileName))
                    {
                        var fields = line.Split(',');
                    }

                }
            }
            catch (Exception errorMsg)
            {
                MessageBox.Show(errorMsg.Message, "Error reading a file", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

      

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lvProfesori.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecteaza un profesor");
                return;
            }
            if (MessageBox.Show("Esti sigur?", "Sterge profesorul", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {

                ListViewItem selectedItem = lvProfesori.SelectedItems[0];
                Profesori profesor = (Profesori)selectedItem.Tag;
                profesori.Remove(profesor);
                DisplayProfesori();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {

            EditProfesor();
        }

        private void lvProfesori_DoubleClick(object sender, EventArgs e)
        {
            EditProfesor();

        }
    private void EditProfesor()
        {
            if (lvProfesori.SelectedItems.Count == 0)
            {
                MessageBox.Show("Te rog selecteaza un profesor");
                return;
            }
            ListViewItem selectedItem = lvProfesori.SelectedItems[0];
            Profesori profesor = (Profesori)selectedItem.Tag;

            FormEdit editForm = new FormEdit(profesor);
            editForm.ShowDialog();
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                DisplayProfesori();
            }
        }

        private void AdaugareProfesor_Load(object sender, EventArgs e)
        {
            LoadDataAndPopulateComboBox();
            // LoadProfesori();
            DisplayProfesori();
        }
        #endregion

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        private int printIndex;
        private void printDocument_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            printIndex = 0;

        }

        private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int rowHeight = 40; 
            System.Drawing.Font font = new System.Drawing.Font("Microsoft Sans Serif", 24);
            var currentY = e.PageSettings.Margins.Top;
              while(printIndex < profesori.Count)
            {
                var currentX = e.PageSettings.Margins.Left;

                e.Graphics.DrawString(profesori[printIndex].Nume, font,
                    Brushes.Black,
                    currentX,currentY);
                printIndex++;
                currentY += rowHeight;

                if(currentY + rowHeight > e.PageSettings.PrintableArea.Height)
                {
                    e.HasMorePages = true;
                    break;

                }

            }
            }

        private void btnPrint_Click_1(object sender, EventArgs e)
        {
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }
    }
}
