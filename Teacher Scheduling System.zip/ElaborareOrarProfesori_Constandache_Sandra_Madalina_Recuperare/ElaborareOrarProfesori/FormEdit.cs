﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ElaborareOrarProfesori
{
    public partial class FormEdit : Form
    {
        private Profesori profesor;
        public FormEdit(Profesori profesor)
        {

            InitializeComponent();
            this.profesor = profesor;
        }

        private void FormEdit_Load(object sender, EventArgs e)
        {
            tbNume.Text = profesor.Nume;
            tbPrenume.Text = profesor.Prenume;
            tbMobil.Text = profesor.TelMobil.ToString();
            comboFunctie.DataSource = Enum.GetValues(typeof(Functie));
            LoadDataAndPopulateComboBox();
            comboFunctie.SelectedItem = profesor.Functie;
            comboDisciplina.SelectedItem = profesor.Disciplina;
            
        }

        private void LoadDataAndPopulateComboBox()
        {

            XmlSerializer serializer = new XmlSerializer(typeof(List<Discipline>));
            using (StreamReader sr = new StreamReader("SerializedDiscipline.xml"))
            {
                List<Discipline> listaDiscipline = (List<Discipline>)serializer.Deserialize(sr);


                comboDisciplina.DataSource = listaDiscipline;
                comboDisciplina.DisplayMember = "Denumire";
                comboDisciplina.ValueMember = "CodDisciplina";
            }
        }


        private void btnSaveEdit_Click(object sender, EventArgs e)
        {
            profesor.Nume = tbNume.Text;
            profesor.Prenume = tbPrenume.Text;
            profesor.TelMobil = int.Parse(tbMobil.Text);
            profesor.Functie = (Functie)comboFunctie.SelectedItem;
            profesor.Disciplina = (Discipline)comboDisciplina.SelectedItem;


        }


    }
}
